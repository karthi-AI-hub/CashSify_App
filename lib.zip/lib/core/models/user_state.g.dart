// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_state.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UserState _$UserStateFromJson(Map<String, dynamic> json) => UserState(
      id: json['id'] as String,
      email: json['email'] as String,
      name: json['name'] as String?,
      phoneNumber: json['phoneNumber'] as String?,
      gender: json['gender'] as String?,
      dob: json['dob'] == null ? null : DateTime.parse(json['dob'] as String),
      coins: (json['coins'] as num).toInt(),
      referralCode: json['referralCode'] as String,
      referralCount: (json['referralCount'] as num?)?.toInt(),
      referredBy: json['referredBy'] as String?,
      upiId: json['upiId'] as String?,
      bankAccount: json['bankAccount'] as Map<String, dynamic>?,
      isVerified: json['isVerified'] as bool,
      profileImageUrl: json['profileImageUrl'] as String?,
      profileUpdatedAt: json['profileUpdatedAt'] == null
          ? null
          : DateTime.parse(json['profileUpdatedAt'] as String),
      lastLogin: json['lastLogin'] == null
          ? null
          : DateTime.parse(json['lastLogin'] as String),
      createdAt: DateTime.parse(json['createdAt'] as String),
      isEmailVerified: json['isEmailVerified'] as bool?,
    );

Map<String, dynamic> _$UserStateToJson(UserState instance) => <String, dynamic>{
      'id': instance.id,
      'email': instance.email,
      'name': instance.name,
      'phoneNumber': instance.phoneNumber,
      'gender': instance.gender,
      'dob': instance.dob?.toIso8601String(),
      'coins': instance.coins,
      'referralCode': instance.referralCode,
      'referralCount': instance.referralCount,
      'referredBy': instance.referredBy,
      'upiId': instance.upiId,
      'bankAccount': instance.bankAccount,
      'isVerified': instance.isVerified,
      'profileImageUrl': instance.profileImageUrl,
      'profileUpdatedAt': instance.profileUpdatedAt?.toIso8601String(),
      'lastLogin': instance.lastLogin?.toIso8601String(),
      'createdAt': instance.createdAt.toIso8601String(),
      'isEmailVerified': instance.isEmailVerified,
    };
