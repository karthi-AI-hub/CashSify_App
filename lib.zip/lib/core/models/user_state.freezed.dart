// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$UserState {
  String get id => throw _privateConstructorUsedError;
  String get email => throw _privateConstructorUsedError;
  String? get name => throw _privateConstructorUsedError;
  String? get phoneNumber => throw _privateConstructorUsedError;
  String? get gender => throw _privateConstructorUsedError;
  DateTime? get dob => throw _privateConstructorUsedError;
  int get coins => throw _privateConstructorUsedError;
  String get referralCode => throw _privateConstructorUsedError;
  int? get referralCount => throw _privateConstructorUsedError;
  String? get referredBy => throw _privateConstructorUsedError;
  String? get upiId => throw _privateConstructorUsedError;
  Map<String, dynamic>? get bankAccount => throw _privateConstructorUsedError;
  bool get isVerified => throw _privateConstructorUsedError;
  String? get profileImageUrl => throw _privateConstructorUsedError;
  DateTime? get profileUpdatedAt => throw _privateConstructorUsedError;
  DateTime? get lastLogin => throw _privateConstructorUsedError;
  DateTime get createdAt => throw _privateConstructorUsedError;
  bool? get isEmailVerified => throw _privateConstructorUsedError;

  /// Create a copy of UserState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $UserStateCopyWith<UserState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserStateCopyWith<$Res> {
  factory $UserStateCopyWith(UserState value, $Res Function(UserState) then) =
      _$UserStateCopyWithImpl<$Res, UserState>;
  @useResult
  $Res call(
      {String id,
      String email,
      String? name,
      String? phoneNumber,
      String? gender,
      DateTime? dob,
      int coins,
      String referralCode,
      int? referralCount,
      String? referredBy,
      String? upiId,
      Map<String, dynamic>? bankAccount,
      bool isVerified,
      String? profileImageUrl,
      DateTime? profileUpdatedAt,
      DateTime? lastLogin,
      DateTime createdAt,
      bool? isEmailVerified});
}

/// @nodoc
class _$UserStateCopyWithImpl<$Res, $Val extends UserState>
    implements $UserStateCopyWith<$Res> {
  _$UserStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of UserState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? email = null,
    Object? name = freezed,
    Object? phoneNumber = freezed,
    Object? gender = freezed,
    Object? dob = freezed,
    Object? coins = null,
    Object? referralCode = null,
    Object? referralCount = freezed,
    Object? referredBy = freezed,
    Object? upiId = freezed,
    Object? bankAccount = freezed,
    Object? isVerified = null,
    Object? profileImageUrl = freezed,
    Object? profileUpdatedAt = freezed,
    Object? lastLogin = freezed,
    Object? createdAt = null,
    Object? isEmailVerified = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      dob: freezed == dob
          ? _value.dob
          : dob // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      coins: null == coins
          ? _value.coins
          : coins // ignore: cast_nullable_to_non_nullable
              as int,
      referralCode: null == referralCode
          ? _value.referralCode
          : referralCode // ignore: cast_nullable_to_non_nullable
              as String,
      referralCount: freezed == referralCount
          ? _value.referralCount
          : referralCount // ignore: cast_nullable_to_non_nullable
              as int?,
      referredBy: freezed == referredBy
          ? _value.referredBy
          : referredBy // ignore: cast_nullable_to_non_nullable
              as String?,
      upiId: freezed == upiId
          ? _value.upiId
          : upiId // ignore: cast_nullable_to_non_nullable
              as String?,
      bankAccount: freezed == bankAccount
          ? _value.bankAccount
          : bankAccount // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      isVerified: null == isVerified
          ? _value.isVerified
          : isVerified // ignore: cast_nullable_to_non_nullable
              as bool,
      profileImageUrl: freezed == profileImageUrl
          ? _value.profileImageUrl
          : profileImageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      profileUpdatedAt: freezed == profileUpdatedAt
          ? _value.profileUpdatedAt
          : profileUpdatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      lastLogin: freezed == lastLogin
          ? _value.lastLogin
          : lastLogin // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isEmailVerified: freezed == isEmailVerified
          ? _value.isEmailVerified
          : isEmailVerified // ignore: cast_nullable_to_non_nullable
              as bool?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$UserStateImplCopyWith<$Res>
    implements $UserStateCopyWith<$Res> {
  factory _$$UserStateImplCopyWith(
          _$UserStateImpl value, $Res Function(_$UserStateImpl) then) =
      __$$UserStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String email,
      String? name,
      String? phoneNumber,
      String? gender,
      DateTime? dob,
      int coins,
      String referralCode,
      int? referralCount,
      String? referredBy,
      String? upiId,
      Map<String, dynamic>? bankAccount,
      bool isVerified,
      String? profileImageUrl,
      DateTime? profileUpdatedAt,
      DateTime? lastLogin,
      DateTime createdAt,
      bool? isEmailVerified});
}

/// @nodoc
class __$$UserStateImplCopyWithImpl<$Res>
    extends _$UserStateCopyWithImpl<$Res, _$UserStateImpl>
    implements _$$UserStateImplCopyWith<$Res> {
  __$$UserStateImplCopyWithImpl(
      _$UserStateImpl _value, $Res Function(_$UserStateImpl) _then)
      : super(_value, _then);

  /// Create a copy of UserState
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? email = null,
    Object? name = freezed,
    Object? phoneNumber = freezed,
    Object? gender = freezed,
    Object? dob = freezed,
    Object? coins = null,
    Object? referralCode = null,
    Object? referralCount = freezed,
    Object? referredBy = freezed,
    Object? upiId = freezed,
    Object? bankAccount = freezed,
    Object? isVerified = null,
    Object? profileImageUrl = freezed,
    Object? profileUpdatedAt = freezed,
    Object? lastLogin = freezed,
    Object? createdAt = null,
    Object? isEmailVerified = freezed,
  }) {
    return _then(_$UserStateImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      email: null == email
          ? _value.email
          : email // ignore: cast_nullable_to_non_nullable
              as String,
      name: freezed == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String?,
      phoneNumber: freezed == phoneNumber
          ? _value.phoneNumber
          : phoneNumber // ignore: cast_nullable_to_non_nullable
              as String?,
      gender: freezed == gender
          ? _value.gender
          : gender // ignore: cast_nullable_to_non_nullable
              as String?,
      dob: freezed == dob
          ? _value.dob
          : dob // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      coins: null == coins
          ? _value.coins
          : coins // ignore: cast_nullable_to_non_nullable
              as int,
      referralCode: null == referralCode
          ? _value.referralCode
          : referralCode // ignore: cast_nullable_to_non_nullable
              as String,
      referralCount: freezed == referralCount
          ? _value.referralCount
          : referralCount // ignore: cast_nullable_to_non_nullable
              as int?,
      referredBy: freezed == referredBy
          ? _value.referredBy
          : referredBy // ignore: cast_nullable_to_non_nullable
              as String?,
      upiId: freezed == upiId
          ? _value.upiId
          : upiId // ignore: cast_nullable_to_non_nullable
              as String?,
      bankAccount: freezed == bankAccount
          ? _value._bankAccount
          : bankAccount // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      isVerified: null == isVerified
          ? _value.isVerified
          : isVerified // ignore: cast_nullable_to_non_nullable
              as bool,
      profileImageUrl: freezed == profileImageUrl
          ? _value.profileImageUrl
          : profileImageUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      profileUpdatedAt: freezed == profileUpdatedAt
          ? _value.profileUpdatedAt
          : profileUpdatedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      lastLogin: freezed == lastLogin
          ? _value.lastLogin
          : lastLogin // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      createdAt: null == createdAt
          ? _value.createdAt
          : createdAt // ignore: cast_nullable_to_non_nullable
              as DateTime,
      isEmailVerified: freezed == isEmailVerified
          ? _value.isEmailVerified
          : isEmailVerified // ignore: cast_nullable_to_non_nullable
              as bool?,
    ));
  }
}

/// @nodoc

class _$UserStateImpl implements _UserState {
  const _$UserStateImpl(
      {required this.id,
      required this.email,
      this.name,
      this.phoneNumber,
      this.gender,
      this.dob,
      required this.coins,
      required this.referralCode,
      this.referralCount,
      this.referredBy,
      this.upiId,
      final Map<String, dynamic>? bankAccount,
      required this.isVerified,
      this.profileImageUrl,
      this.profileUpdatedAt,
      this.lastLogin,
      required this.createdAt,
      this.isEmailVerified})
      : _bankAccount = bankAccount;

  @override
  final String id;
  @override
  final String email;
  @override
  final String? name;
  @override
  final String? phoneNumber;
  @override
  final String? gender;
  @override
  final DateTime? dob;
  @override
  final int coins;
  @override
  final String referralCode;
  @override
  final int? referralCount;
  @override
  final String? referredBy;
  @override
  final String? upiId;
  final Map<String, dynamic>? _bankAccount;
  @override
  Map<String, dynamic>? get bankAccount {
    final value = _bankAccount;
    if (value == null) return null;
    if (_bankAccount is EqualUnmodifiableMapView) return _bankAccount;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  final bool isVerified;
  @override
  final String? profileImageUrl;
  @override
  final DateTime? profileUpdatedAt;
  @override
  final DateTime? lastLogin;
  @override
  final DateTime createdAt;
  @override
  final bool? isEmailVerified;

  @override
  String toString() {
    return 'UserState(id: $id, email: $email, name: $name, phoneNumber: $phoneNumber, gender: $gender, dob: $dob, coins: $coins, referralCode: $referralCode, referralCount: $referralCount, referredBy: $referredBy, upiId: $upiId, bankAccount: $bankAccount, isVerified: $isVerified, profileImageUrl: $profileImageUrl, profileUpdatedAt: $profileUpdatedAt, lastLogin: $lastLogin, createdAt: $createdAt, isEmailVerified: $isEmailVerified)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$UserStateImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.email, email) || other.email == email) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.phoneNumber, phoneNumber) ||
                other.phoneNumber == phoneNumber) &&
            (identical(other.gender, gender) || other.gender == gender) &&
            (identical(other.dob, dob) || other.dob == dob) &&
            (identical(other.coins, coins) || other.coins == coins) &&
            (identical(other.referralCode, referralCode) ||
                other.referralCode == referralCode) &&
            (identical(other.referralCount, referralCount) ||
                other.referralCount == referralCount) &&
            (identical(other.referredBy, referredBy) ||
                other.referredBy == referredBy) &&
            (identical(other.upiId, upiId) || other.upiId == upiId) &&
            const DeepCollectionEquality()
                .equals(other._bankAccount, _bankAccount) &&
            (identical(other.isVerified, isVerified) ||
                other.isVerified == isVerified) &&
            (identical(other.profileImageUrl, profileImageUrl) ||
                other.profileImageUrl == profileImageUrl) &&
            (identical(other.profileUpdatedAt, profileUpdatedAt) ||
                other.profileUpdatedAt == profileUpdatedAt) &&
            (identical(other.lastLogin, lastLogin) ||
                other.lastLogin == lastLogin) &&
            (identical(other.createdAt, createdAt) ||
                other.createdAt == createdAt) &&
            (identical(other.isEmailVerified, isEmailVerified) ||
                other.isEmailVerified == isEmailVerified));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      email,
      name,
      phoneNumber,
      gender,
      dob,
      coins,
      referralCode,
      referralCount,
      referredBy,
      upiId,
      const DeepCollectionEquality().hash(_bankAccount),
      isVerified,
      profileImageUrl,
      profileUpdatedAt,
      lastLogin,
      createdAt,
      isEmailVerified);

  /// Create a copy of UserState
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$UserStateImplCopyWith<_$UserStateImpl> get copyWith =>
      __$$UserStateImplCopyWithImpl<_$UserStateImpl>(this, _$identity);
}

abstract class _UserState implements UserState {
  const factory _UserState(
      {required final String id,
      required final String email,
      final String? name,
      final String? phoneNumber,
      final String? gender,
      final DateTime? dob,
      required final int coins,
      required final String referralCode,
      final int? referralCount,
      final String? referredBy,
      final String? upiId,
      final Map<String, dynamic>? bankAccount,
      required final bool isVerified,
      final String? profileImageUrl,
      final DateTime? profileUpdatedAt,
      final DateTime? lastLogin,
      required final DateTime createdAt,
      final bool? isEmailVerified}) = _$UserStateImpl;

  @override
  String get id;
  @override
  String get email;
  @override
  String? get name;
  @override
  String? get phoneNumber;
  @override
  String? get gender;
  @override
  DateTime? get dob;
  @override
  int get coins;
  @override
  String get referralCode;
  @override
  int? get referralCount;
  @override
  String? get referredBy;
  @override
  String? get upiId;
  @override
  Map<String, dynamic>? get bankAccount;
  @override
  bool get isVerified;
  @override
  String? get profileImageUrl;
  @override
  DateTime? get profileUpdatedAt;
  @override
  DateTime? get lastLogin;
  @override
  DateTime get createdAt;
  @override
  bool? get isEmailVerified;

  /// Create a copy of UserState
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$UserStateImplCopyWith<_$UserStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
